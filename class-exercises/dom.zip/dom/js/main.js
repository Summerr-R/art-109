

document.querySelector("#image1").addEventListener("click", function(){
    document.querySelector("#image1").style.visibility = "hidden";
})
document.querySelector("#image2").addEventListener("click", function(){
    document.querySelector("#image2").style.visibility = "hidden";
})
document.querySelector("#image3").addEventListener("click", function(){
    document.querySelector("#image3").style.visibility = "hidden";
})
document.querySelector("#image4").addEventListener("click", function(){
    document.querySelector("#image4").style.visibility = "hidden";
})